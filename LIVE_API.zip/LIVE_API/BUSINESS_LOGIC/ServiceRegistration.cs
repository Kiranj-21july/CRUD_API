﻿using BUSINESS_LOGIC.BusinessLogic;
using IBUSINESS_LOGIC.IBusinessLogic;
using Microsoft.Extensions.DependencyInjection;

namespace BUSINESS_LOGIC
{
    public static class ServiceRegistration
    {
        public static void AddInfrastructure(this IServiceCollection services)
        {
            services.AddTransient<IUnitOfWork,UnitOfWork>();
            services.AddTransient<ICRUD_Management,CRUD_Management>();
        }
    }
}
