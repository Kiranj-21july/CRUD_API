﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using IBUSINESS_LOGIC.IBusinessLogic;
using Microsoft.Extensions.Configuration;
using MODELS;

namespace BUSINESS_LOGIC.BusinessLogic
{
    public class CRUD_Management : ICRUD_Management
    {
        private readonly IConfiguration configuration;
        public CRUD_Management(IConfiguration configuration) {
            this.configuration = configuration;
        }

        public async Task<IReadOnlyList<CRUD_Model>> GetAllAsync()
        {
            try
            {
                 string procedure = "sp_Am_AuditCategory_Master_crud";
                using (var connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection")))
                {
                    var parameters = new
                    {
                        Action = 1
                    };
                    return (await connection.QueryAsync<CRUD_Model>(procedure, parameters, commandType: CommandType.StoredProcedure).ConfigureAwait(false)).AsList();
                }
            }
            catch (Exception )
            {
                throw;
            } 
        }

      
    }
}
