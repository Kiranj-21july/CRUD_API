﻿using IBUSINESS_LOGIC.IBusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUSINESS_LOGIC.BusinessLogic
{
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork(ICRUD_Management CRUD_Repository) {
            CRUD_Masters = CRUD_Repository;
        }
        public ICRUD_Management CRUD_Masters { get; }
    }
}
