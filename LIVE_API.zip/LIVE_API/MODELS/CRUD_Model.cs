﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODELS
{
    public class CRUD_Model
    {
        public string? Action { get; set; }
        public string? Audit_Category_Id { get; set; }
        public string? Audit_Category_Name { get; set; }
    }

    public class RETURN_MESSAGE
    {
        public string? STATUS_CODE { get; set; }
        public bool? STATUS { get; set; }
        public string? MESSAGE { get; set; }
        public string? UNIQUE_ID { get; set; }
        public string? Return_Status { get; set; }
        public string? RecordsTotal { get; set; }
        public string? RecordsFiltered { get; set; }
    }
}
