﻿namespace MODELS
{
    public class Class1
    {

    }
}
