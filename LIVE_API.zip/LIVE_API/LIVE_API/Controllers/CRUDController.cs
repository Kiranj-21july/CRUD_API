﻿using BUSINESS_LOGIC.BusinessLogic;
using IBUSINESS_LOGIC.IBusinessLogic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MODELS;

namespace LIVE_API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CRUDController : ControllerBase
    {
        private readonly IUnitOfWork unitofwork;
        private IWebHostEnvironment hostEnvironment;

        public CRUDController(IUnitOfWork unitofwork, IWebHostEnvironment hostEnvironment)
        {
            this.unitofwork = unitofwork;
            this.hostEnvironment = hostEnvironment;
        }
        [HttpGet]
        public async Task<IActionResult> GetIndex()
        {
            var data = await unitofwork.CRUD_Masters.GetAllAsync();
            if (data.Count > 0)
            {
                var b = new
                {
                    Get_All = data,
                    MESSAGE = "Success",
                    STATUS = true,
                    STATUS_CODE = "200"

                };
                return Ok(b);
            }
            else
            {
                RETURN_MESSAGE errormessage = new RETURN_MESSAGE()
                {
                    MESSAGE = "No Records Found",
                    STATUS = false,
                    STATUS_CODE = "404"
                };

                return Ok(errormessage);
            }
        }
    }
}
