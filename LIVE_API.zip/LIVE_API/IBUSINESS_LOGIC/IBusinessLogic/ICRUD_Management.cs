﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MODELS;

namespace IBUSINESS_LOGIC.IBusinessLogic
{
    public interface ICRUD_Management : IGenericRepository<CRUD_Model>
    {
       
    }

    
}
