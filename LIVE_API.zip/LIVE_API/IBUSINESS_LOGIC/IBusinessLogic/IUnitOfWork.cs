﻿

namespace IBUSINESS_LOGIC.IBusinessLogic
{
    public interface IUnitOfWork
    {
        ICRUD_Management CRUD_Masters { get; }
    }
}
